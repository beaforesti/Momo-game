<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="Colori lv2" tilewidth="32" tileheight="32" tilecount="296" columns="8">
 <image source="Colori lv2.png" width="267" height="1201"/>
</tileset>
